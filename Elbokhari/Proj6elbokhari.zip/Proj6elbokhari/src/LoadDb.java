import java.io.File;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class LoadDb {
	//car, make, country, body_type, year
    public static void main(String[] args) {
        Connection c = null;
        Statement s = null;
        Scanner fromFile = null;
        String sql1 = null, sql2 = null;
        String line = null, car = null, make = null, country = null,
        	bodyType = null;
        
        String[ ] fields;
        int year = 0;

        try {
            // Define Connection and Statement objects.
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:cars.db");
            s = c.createStatement();

            // Instantiate scanner to read from file.
            fromFile = new Scanner(new File ("cars.txt"));
        
            // Create kids table.
            sql1 = "create table if not exists cars (" +
                "car varchar(10), " +
                "make varchar(15), " +
                "country varchar(15), " +
                "body_type varchar(15), " +
                "year integer);";
            System.out.println("sql1: " + sql1);
            s.executeUpdate(sql1);
            
            // Read and throw away header line.
            fromFile.nextLine( );
            //car, make, country, body_type, year
            // Populate kids table.
            while (fromFile.hasNextLine( )) {
                line = fromFile.nextLine( );
                fields = line.split(",");
                car = fields[0].trim( );
                make = fields[1].trim( );
                country = fields[2].trim( );
                bodyType = fields[3].trim( );
                year = Integer.parseInt(fields[4].trim( ));
                sql2 = String.format(
                    "insert into cars " +
                    "(car, make, country, body_type, year) " +
                    "values ('%s', '%s', '%s','%s', %d);", 
                    car, make, country,
                    bodyType, year);
                
                System.out.println(sql2);
                s.executeUpdate(sql2);
            }
            c.close( );
        }
        catch (FileNotFoundException e) {
            System.out.println("File queries.sql not found.");
            System.err.println( e.getClass().getName() + 
                ": " + e.getMessage() );
        }
        catch(SQLException e) {
            System.out.println("SQLException.");
            System.err.println( e.getClass().getName() + 
                ": " + e.getMessage() );
        }
        catch (ClassNotFoundException e ) {
            System.err.println( e.getClass().getName() + 
                ": " + e.getMessage() );
        }
        finally {
            fromFile.close( );
        }
    }
}