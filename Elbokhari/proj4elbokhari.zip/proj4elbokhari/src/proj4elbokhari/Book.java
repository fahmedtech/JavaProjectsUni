//Ahmed El bokhari
// IT 313 Project 4
// 03-04-2016

package proj4elbokhari;

import java.io.Serializable;

/**
 * 
 * @author Ahmed El bokhari
 *
 */
public class Book extends LibraryItem implements Serializable {

	public String _author, _publisher;
	private static final long serialVersionUID = 2L;

	public Book( ){ 
		
	}

	/**
	 * constructor - creates a book item
	 * @param id - is the id of the library item
	 * @param title - is the title of the library item
	 * @param year - is the year when the library item was published 
	 * @param author - is the author of the library item
	 * @param publisher - is the publisher of the item
	 */
	public Book(int id, String title, int year, String author, String publisher){
		super(id, title, year);
		_author = author;
		_publisher = publisher;
	}

	
	/**
	 * the get method for author
	 * @return the Author of the book
	 */
	public String getAuthor( ) { 
		return _author;	
	}

	
	/**
	 * the get method for publisher
	 * @return the publisher
	 */
	public String getPublisher( ) { 
		return _publisher; 
	}


	@Override
	/**
	 * returns the string of the book items
	 */
	public String toString( ){
		return super.toString( ) + "\n" + 
			   "Author: " + getAuthor( ) + "\n" + 
				"Publisher: " + getPublisher( ) + "\n";
	}

}


