//Ahmed El bokhari
// IT 313 Project 4
// 03-04-2016

package proj4elbokhari;


import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

/**
 * 
 * @author Ahmed El bokhari
 * creates arraylist to add library items
 *
 */
public class LibraryCollection implements Iterable<LibraryItem>, Serializable {

	public ArrayList<LibraryItem> _col;
	private static final long serialVersionUID = 4L;

	/**
	 * create a new arraylist for library collection
	 */
	public LibraryCollection( ){
		_col = new ArrayList<LibraryItem>( );
	}

	@Override
	/**
	 * iterates over the arraylist
	 */
	public Iterator<LibraryItem> iterator( ) {
		return _col.iterator( );
	}

	/**
	 * adds a book to the collection items
	 * @param bookItem -- add the book Item 
	 */
	public void addBook(Book bookItem){
		_col.add(bookItem);
	}

	/**
	 * adds music to collection items
	 * @param musicCD -- add the musicCD 
	 */
	public void addMusicCD(MusicCD musicCD){
		_col.add(musicCD);
	}

	/**
	 * gets the collection item with the same id
	 * @param number -- the id of the library item
	 * @return -- collection item with same id
	 */
	public String getItem(int number){
		String res = "";
		for(LibraryItem item: _col){
			if(item.getID( ) == number)
				res += item;
		}
		return res;
	}

/**
 * removes an object from the collection item
 * @param number -- id of the library item
 */
	public void removeItem(int number){
		for(LibraryItem item : _col)
			if(item.getID() == number)
				_col.remove(item);	
			else
				System.out.println("");
	}

	/**
	 * displays all of the object of the collection item
	 */
	public void displayAll( ){
		for(LibraryItem item: _col){
			System.out.println(item);
		}
	}

	/** 
	 * it find an item within the collection
	 * @param word -- the word of the item in the libraryitem
   	 * @return item of the collection
 	 */
	public String find(String word){
		Collections.sort(_col);
		String res = "";
		for(LibraryItem item : _col){
			if(item.getTitle( ).trim( ).toLowerCase().contains(word)){
				res += item + "\n";
			}
		}
		return res;
	}
	/**
	 * saves the new added item
	 * @throws IOException -- 
	 */
	public void save( ) throws IOException{
		ObjectOutputStream output = 
				new ObjectOutputStream(
				new FileOutputStream("colFile.ser"));
		output.writeObject(_col);
		output.close();
	}

	@SuppressWarnings("unchecked")
	/**
	 * de-serialize file 
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	public void load( ) throws IOException, ClassNotFoundException{
		ObjectInputStream input = 
				new ObjectInputStream(
				new FileInputStream("colFile.ser"));
		_col = (ArrayList<LibraryItem>) input.readObject( );
		input.close( );
	}

}

