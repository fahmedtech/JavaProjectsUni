//Ahmed El bokhari
// IT 313 Project 4
// 03-04-2016


package proj4elbokhari;


import java.io.Serializable;

public class MusicCD extends LibraryItem implements Serializable{

	public String _performer, _composer, _label;
	private static final long serialVersionUID = 3L;

	public MusicCD( ) {

	}

	public MusicCD(int id, String title, int year, String performer, String composer, String label){
		super(id, title, year);
		_performer = performer;
		_composer = composer;
		_label = label;
	}

	/**
	 * gets the Performer
	 * @return the Performer
	 */
	public String getPerformer( ) { 
		return _performer; 
	}

	/**
	 * gets the Composer
	 * @return the Composer
	 */
	public String getComposer( ) { 
		return _composer; 
	}
	/**
	 * Gets the Label
	 * @return the Label
	 */
	public String getLabel( ) { 
		return _label; 
	}


	@Override
	/**
	 * return the string of music cd item
	 */
	public String toString( ){
		return super.toString( ) + "\n" +
				"Performer: " + getPerformer( ) + "\n" +
				"Composer: " + getComposer( ) + "\n" + 
				"Label : " + getLabel( ) +  "\n";
	}

}


