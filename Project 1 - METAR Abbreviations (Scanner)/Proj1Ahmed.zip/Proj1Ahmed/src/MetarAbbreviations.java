/**
 * @author Faizan Ahmed
 * IT313 - Project 1 
 * Program: Read one of the 8 abbreviations,
 * 			then print its English meaning.
 * 			(+  -  B  DZ  E  HZ  RA  SN)
 */

import java.util.Scanner;

public class MetarAbbreviations {

	public static void main(String[] args) {

		//scanner object - converted toUpperCase()
		Scanner in = new Scanner(System.in);
		System.err.print("Enter Metar Abbreviation: ");
		String metar = in.nextLine().toUpperCase();

		//initialize variable 'trans'
		String trans;

		//checking if input value matches metar abbreviations
		if(metar.equals("+")){
			trans = "Heavy (intensity/proximity)";}
		else if(metar.equals("-")){
			trans = "Light (intensity/proximity)";}
		else if(metar.equals("B")){
			trans = "Began at Time";}
		else if(metar.equals("DZ")){
			trans = "Drizzle";}
		else if(metar.equals("E")){
			trans = "Ended";}
		else if(metar.equals("HZ")){
			trans = "Haze";}
		else if(metar.equals("RA")){
			trans = "Rain";}
		else if(metar.equals("SN")){
			trans = "Snow";}
		else{
			trans = "-1";}

		//printing output and checking for invalid input
		if(trans.equals("-1")){
			System.out.print("Illegal Input!");}
		else{
			System.out.printf("Translation: %s", trans);}

		//closing scanner object
		in.close();
	}

}
