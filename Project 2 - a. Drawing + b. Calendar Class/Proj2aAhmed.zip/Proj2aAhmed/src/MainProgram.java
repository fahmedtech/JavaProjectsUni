/**
 IT 313
 @author Faizan Ahmed
 Project 2a - Drawing in a Swing Panel
 Program: Draw your picture using methods from
 		  classes, Color, Font, and Graphics.
 */

//creating the frame that displays the drawing
//run the main program to create the drawing on window

public class MainProgram {

	public static void main(String[] args) {
		new MyFrame();
	}
}
