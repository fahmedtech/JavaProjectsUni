/**
 IT 313
 @author Faizan Ahmed
 Project 2a - Drawing in a Swing Panel
 Program: Draw your picture using methods from
 		  classes, Color, Font, and Graphics.
 */


//defining the frame from the Swing class JFrame.

import javax.swing.*;
import java.awt.*;

public class MyFrame extends JFrame {

	private MyPanel p;

	public MyFrame(){

		//window title
		super("Faizan's Java Drawing");
		p = new MyPanel();
		p.setLayout(new FlowLayout());

		//setting the size and visibility of the panel
		setContentPane(p);
		setSize(500,600);
		setVisible(true);

	}
}
