/**
 IT 313
 @author Faizan Ahmed
 Project 2a - Drawing in a Swing Panel
 Program: Draw your picture using methods from
 		  classes, Color, Font, and Graphics.
 */

//creating panel based on Swing Class
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MyPanel extends JPanel {

	//panel's background setting
	public MyPanel(){
		setBackground(Color.black);
	}

	//method - draw objects on the panel
	public void paintComponent(Graphics g){
		super.paintComponent(g);

		//print string title
		g.setFont(new Font("arial", Font.BOLD, 30));
		g.setColor(Color.white);
		g.drawString("Hello World, Windows", 80, 60);

		//draw circle
		Color c0 = new Color(255,253,208);
		g.setColor(c0);
		g.fillOval(15, 90, 450, 450);
		g.setColor(Color.black);
		g.drawOval(15, 90, 450, 450);

		//drawing 1st - red square
		Color c1 = new Color(242,80,34);
		g.setColor(c1);
		g.fillRoundRect(90, 165, 150, 150, 10, 10);
		g.setColor(Color.black);
		g.drawRoundRect(90, 165, 150, 150, 10, 10);

		//drawing 2nd - blue square.
		Color c2 = new Color(1,64,239);
		g.setColor(c2);
		g.fillRoundRect(90, 320, 150, 150, 10, 10);
		g.setColor(Color.black);
		g.drawRoundRect(90, 320, 150, 150, 10, 10);

		//drawing 3rd - green square
		Color c3 = new Color(53,240,88);
		g.setColor(c3);
		g.fillRoundRect(245, 165, 150, 150, 10, 10);
		g.setColor(Color.black);
		g.drawRoundRect(245, 165, 150, 150, 10, 10);

		//drawing 4th - yellow square
		Color c4 = new Color(255,185,1);
		g.setColor(c4);
		g.fillRoundRect(245, 320, 150, 150, 10, 10);
		g.setColor(Color.black);
		g.drawRoundRect(245, 320, 150, 150, 10, 10);
	}
}
