/**
 @author Faizan Ahmed
 IT313 - Project 2b (Find Day of Week)
 Program: Repeatedly enters a date and prints the 
 		  day of the week that corresponds to each 
 		  input date.

		  Uses Calendar class object.
 */

import java.util.Calendar;
import java.util.Scanner;

public class CalendarDay_Proj2bAhmed {

	public static void main(String[] args) {

		String response = "";

		//scanner object with input prompt
		Scanner in = new Scanner(System.in);
		System.err.print("Enter Date in format(mm/dd/yyyy): ");

		//do-while loop - to enter another date if entered y in input(response)
		do{

			//array of 7 days -- constant field value of Sunday: 1 and Saturday: 7
			//index 0 - set empty
			String[] sevenDays = {" ", "Sunday", "Monday", "Tuesday", "Wednesday",
					"Thursday", "Friday", "Saturday"};

			//calendar object
			Calendar calObj = Calendar.getInstance();

			while(in.hasNextLine()){

				//input is stored as String and then splitted with "/"
				String inputDate = in.nextLine();
				String[] splitDate = inputDate.split("/");

				//using try-catch method to throw exceptions
				try{

					//storing and parsing split values of date into int variable fields
					int month = Integer.parseInt(splitDate[0]);
					int day = Integer.parseInt(splitDate[1]);
					int year = Integer.parseInt(splitDate[2]);
					
					//MONTH is 0-based Index - January == 0 
					//remove 1 from month input so that (1 - 1 = 0) == January 
					calObj.set(year, month-1, day);


					//checking errors in date fields 
					if(day < 1 || day > 31){
						System.out.println("Invalid Day! \n"); }
					else if(month < 1 || month > 12){
						System.out.println("Invalid Month! \n"); }
					else{

						//looking up DAY_OF_WEEK through the key in sevenDays
						//DAY_OF_WEEK is 0-based int static method
						int dayIndex  = calObj.get(Calendar.DAY_OF_WEEK);
						String getDay = sevenDays[dayIndex];
						System.out.printf("Day(%s): %s", inputDate, getDay.toUpperCase() + "\n");
					}

				//catching more than one exceptions in the Input
				}catch(NumberFormatException|ArrayIndexOutOfBoundsException n){
					System.out.println("Invalid Date Entered! \n");
				}


				//displaying the prompt again - after 1st use
				System.out.print("Do you wish to continue (y/n)? ");
				response = in.nextLine();

				//if response != y OR is empty line then terminate program
				if(response.trim().equals("") || !response.equalsIgnoreCase("y")){
					System.out.println("Thank you. Bye!");
					break;
				}
				else
					System.err.print("Enter Date in format(mm/dd/yyyy): ");
			}//end of while loop


		}while(response.equalsIgnoreCase("y"));

		in.close();
	}

}

