/**
 @author Faizan Ahmed
 IT313 - Project 3a
 Program: Read input CSV file containing addresses
 		  using Scanner object & File Chooser.
 		  Print Address with POSNET bar code.
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import javax.swing.JFileChooser;

public class PosnetFileAddress_Proj3a {

	public static void main(String[] args) {

		//opening the csv/txt file - chooser
		JFileChooser chooseObj = new JFileChooser();
		chooseObj.showOpenDialog(null);
		File fileObj = chooseObj.getSelectedFile();

		//scanner object to read the csv file, you can also include
		//Scanner(fileObj, "UTF-8") to remove unicode characters.
		try {
			Scanner in = new Scanner(fileObj);

			//reading the file and splitting data using ","
			while(in.hasNextLine()){
				String input = in.nextLine();
				String[] splitInput = input.split(",");

				//dividing input fields
				String name = splitInput[0];
				String address = splitInput[1];
				String city = splitInput[2];
				String state = splitInput[3];
				String zip = splitInput[4];

				//concat all fields as string + calling method getBarCode()
				String completeAddress = 
						String.format("%s\n%s\n%s %s %s\n%s", 
						name, address, city, state, zip, getBarCode(zip)); 

				System.out.println(completeAddress);
			}

			//closing scanner object
			in.close();

		} catch (FileNotFoundException|NullPointerException e) {
			System.out.println("File Not Found Exception!");
		}
	}

	//method - takes zip code and returns barcode 
	public static String getBarCode(String zipcode){

		//barcode array index from (0-9)
		String[] barcode = {"||:::",":::||","::|:|", "::||:", ":|::|", 
							":|:|:", ":||::", "|:::|", "|::|:", "|:|::"};
		
		String t = "|"; String cs = "";
		int zipsum1 = 0, zipsum2 = 0;

		//the initial value i is already in the output String - returned at end
		String output = "|";

		//String output = "";

		//splitting the zipcode
		String[] splitZip = zipcode.split("-");
		String zip1 = splitZip[0];
		String zip2 = splitZip[1];

		//adding values for int in first half of zip by 
		//converting char to int 'digit' and adding to zipsum1
		//also appending the barcode to output by looking through array index 
		for(int x=0; x<zip1.length(); x++){
			char c = zip1.charAt(x); //ASCII value
			int digits1 = Integer.parseInt(c + "");
			zipsum1 += digits1;
			output += "" + barcode[digits1];
			//output += sum1;
		}

		//adding values for int in second half of zip by
		//converting char to int 'digit' and adding to zipsum1
		//also appending the barcode to output by looking through array index
		for(int y=0; y<zip2.length(); y++){
			char c2 = zip2.charAt(y); //ASCII value
			int digits2 = Integer.parseInt(c2 + "");
			zipsum2 += digits2;
			output += "" + barcode[digits2];
			//output += sum2;
		}

		//adding both zip int digits - and checksum
		int sum = zipsum1 + zipsum2;
		//output = total + "";

		int checksum = 10 - (sum % 10);
		if(sum%10 == 0){
			checksum = 0;
		}
		cs += barcode[checksum]; //looking checksum barcode in index

		//complete output string - concatenate bar-code (checksum + terminal) at end
		output += "" + cs + "" + t + "\n";

		return output;
	}

}
