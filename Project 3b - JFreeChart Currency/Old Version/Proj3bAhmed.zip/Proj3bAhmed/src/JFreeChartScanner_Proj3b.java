/**
 @author Faizan Ahmed
 Project 3b - JFreeChart Graph

 IT313 Program: 
 Choose five international source currencies to monitor.
 Each currency is referenced with a three letter ISO 4217 currency code. 
 For example, the code for the U.S. Dollar currency is USD. 
 Search online for these abbreviations with a search string such as "ISO 4217 Currency Codes." 
 Place these currency codes in a text file. 

 The following URL is a link to a CSV file that contains the exchange rate for 
 a given source and target currency. For example, if the source currency is EUR 
 and the target currency is USD, the URL is
 http://download.finance.yahoo.com/d/quotes.csv?s=EURUSD=X&f=sl1d1t1ba&e=.csv 

 Read the five source currencies in the text file that you created in Step 1, 
 dynamically create URLs that are passed to Java Scanner objects to obtain 
 the exchange rates (to USD) for five source currencies from Part 1. 

 Plot the five exchange rates that you found in Step 2 in a JFreeChart bar chart. 
 See the BarChart Example in the jfreechart example file.
 */

//import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.net.MalformedURLException;
import java.net.URL;

//importing things to create bar-chart 
//JAR files jcommon-1.0.23.jar and jfreechart-1.0.19.jar 
//must be added to project.
import java.io.*;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.chart.ChartFactory; 
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.JFreeChart; 
import org.jfree.chart.ChartUtilities; 

//adding all of the currencies to Arraylist - not completely right version //ACER LAPTOP
public class JFreeChartScanner_Proj3b {

	//main method
	public static void main(String[] args) throws MalformedURLException, IOException{

		try {
			
			/*
			//test1
			Scanner in = new Scanner(System.in);
			//File file = new File("curCodes.txt");
			System.out.print("Enter cur: ");
			System.out.println(getCurrency(in));
			*/
			String[] arr = new String[5];
			for(int i=0; i <= 0; i++){
			
				//Scanner sc = new Scanner(System.in);
				ArrayList<String> arr1 = new ArrayList<String>();
				arr1.add(getCurrency(null));				
				System.out.println("arr1 " + arr1);
			
				String output = "";
				
				for(String s: arr1){
					output += s + "";
				}
				
				//separating index of char
				int index = 0;
				while (index<output.length()) {
				    arr1.add(output.substring(index, Math.min(index+3,output.length())));
				    index += 3;
				}arr1.remove(0);
				
				for(String newS : arr1){
					System.out.println(newS);
				}
				
				System.out.println("separated array " + arr1);
				System.out.println(output);
				//arr1.spliterator();
				
				//String x = getCurrency(null);
				
				//Iterator itr = getCurrency(null).iterator();
				

			}
			
			//do we need to use PrintWriter Class?
		//	System.out.println(getCurrency(null)); //use this? or input a Scanner?
			//test2 
			System.out.println(getURLString(getCurrency(null), getCurrency(null))); //wrong
			System.out.println(getURLString("SAR", "PKR"));

			//test3 
			System.out.println(getExchangeRate(getURLString("PKR", "SAR")));
			
			//testing JFreeChart -----------------------------------------------------
            
            // Define data for line chart.
            DefaultCategoryDataset barChartDataset = 
                new DefaultCategoryDataset();
            barChartDataset.addValue(getExchangeRate(getURLString("PKR","SAR")), "total", "PKR-SAR");
            barChartDataset.addValue(getExchangeRate(getURLString("ALL","MXN")),  "total", "ALL-MXN");
            barChartDataset.addValue(getExchangeRate(getURLString("PKR","INR")),  "total", "PKR-INR");                
            barChartDataset.addValue(getExchangeRate(getURLString("MXN","SAR")), "total", "MXN-SAR"); 
            barChartDataset.addValue(getExchangeRate(getURLString("INR","ALL")), "total", "INR-ALL"); 
                
            // Define JFreeChart object that creates line chart.
            JFreeChart barChartObject = ChartFactory.createBarChart(
                "Exchange Rates of Currencies", "(Source-Target) Currency", "Ex. Rate", barChartDataset,
                PlotOrientation.VERTICAL, 
                false,  // Include legend.
                false,  // Include tooltips.
                false); // Include URLs.               
                          
             // Write line chart to a file.               
             int imageWidth = 640;
             int imageHeight = 480;                
             File barChart = new File("exchangeRatesChart.png");              
             ChartUtilities.saveChartAsPNG(
                 barChart, barChartObject, imageWidth, imageHeight); 
        }catch (Exception i)
        {
            System.out.println(i);
        }
	}

	//method #1 - JFreeChartScanner_Proj3b.getCurrency()
	public static String getCurrency(Scanner s) throws FileNotFoundException{
		
		String cur = "";
				
		File fileObj = new File("curCodes.txt");
		s = new Scanner(fileObj);
		
		while(s.hasNextLine()){
			cur += "" + s.nextLine();
		}
		
		//s.close(); - need to close the scanner
		
		//return cur;
		return cur;
		//return s.next().toUpperCase();
	}

	//method #2 - JFreeChartScanner_Proj3b.getURLString()
	public static String getURLString(String sourceCurrency, String targetCurrency){

		String prefix = "http://download.finance.yahoo.com/d/quotes.csv?s=";
		String suffix = "=X&f=sl1d1t1ba&e=.csv";

		String completeURL = String.format("%s%s%s%s", prefix, sourceCurrency.toUpperCase(),
				targetCurrency.toUpperCase(), suffix); 	
		return completeURL;
	}

	//method #3 - JFreeChartScanner_Proj3b.getExchangeRate()
	public static double getExchangeRate(String urlString) throws MalformedURLException, IOException{

		double rate = 0.0;
		try{
			Scanner webRead = new Scanner(new URL(urlString).openStream());
			while(webRead.hasNext()){
				String data = webRead.nextLine();
				String[] splitData = data.split(",");

				//in csv file 0-index is name, 1-index is exchange rate
				rate += Double.parseDouble(splitData[1]);
			}
			webRead.close();

		}catch(NumberFormatException e){
			System.out.println("Invalid Input in Parameter!");
			System.exit(0);
		}
		return rate;
	}
}
