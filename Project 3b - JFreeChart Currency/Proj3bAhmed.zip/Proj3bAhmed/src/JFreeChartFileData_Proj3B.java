/**
 @author Faizan Ahmed
 Project 3b - JFreeChart Graph

 IT313 Program: 
 Choose five international source currencies to monitor.
 Each currency is referenced with a three letter ISO 4217 currency code. 
 For example, the code for the U.S. Dollar currency is USD. 
 Search online for these abbreviations with a search string such as "ISO 4217 Currency Codes." 
 Place these currency codes in a text file. 

 The following URL is a link to a CSV file that contains the exchange rate for 
 a given source and target currency. For example, if the source currency is EUR 
 and the target currency is USD, the URL is
 http://download.finance.yahoo.com/d/quotes.csv?s=EURUSD=X&f=sl1d1t1ba&e=.csv 

 Read the five source currencies in the text file that you created in Step 1, 
 dynamically create URLs that are passed to Java Scanner objects to obtain 
 the exchange rates (to USD) for five source currencies from Part 1. 

 Plot the five exchange rates that you found in Step 2 in a JFreeChart bar chart. 
 See the BarChart Example in the JFreeChart example file.
 */

import java.util.Scanner;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;

//importing things to create bar-chart 
//JAR files jcommon-1.0.23.jar and jfreechart-1.0.19.jar 
//must be added to project.
import java.io.*;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.chart.ChartFactory; 
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.JFreeChart; 
import org.jfree.chart.ChartUtilities;

public class JFreeChartFileData_Proj3B {

	private static String USD = "USD";
	private static String createURL;
	private static double URLrate;

	public static void main(String[] args) {

		try {
			//currency variable reads the file through getCurrency();
			String currency = getCurrency(null);
			String[] arr = currency.split("\\r?\\n"); //split every newline and add to Array 'arr'

			//JFreeChart - define data variable 'barChartDataset' for bar chart.
			DefaultCategoryDataset barChartDataset = new DefaultCategoryDataset();

			//loop through the array 'arr' of currencies - arr.length=5 (5-1) index[0-4]
			for(int i=0; i <= arr.length -1 ; i++){
				String output = "";

				//appending to output -to use the methods
				output += arr[i];

				//calling both methods to private variables
				createURL = getURLString(output, USD);
				URLrate = getExchangeRate(createURL);

				//test: printing output and testing the methods
				System.out.println(output + ": " +  createURL + "\n" +
						"Ex. Rate (USD): " + URLrate + "\n");

				//putting values into the chart
				barChartDataset.addValue(URLrate, "rate", String.format("%s-%s", output, USD));

				// Define JFreeChart object that creates line chart.
				JFreeChart barChartObject = ChartFactory.createBarChart(
						"Exchange Rates of Currencies", "(Source-Target) Currency", "Ex. Rate", 
						barChartDataset, PlotOrientation.VERTICAL, 
						false,  // Include legend.
						false,  // Include tooltips.
						false); // Include URLs.               

				// Write line chart to a file.               
				int imageWidth = 640;
				int imageHeight = 480;                
				File barChart = new File("exchangeRatesBarChart.png");              
				ChartUtilities.saveChartAsPNG(
						barChart, barChartObject, imageWidth, imageHeight); 
			}//end of for-loop

			String dateTime = new SimpleDateFormat("MM/dd/yy hh:mm:ss a").format(
					Calendar.getInstance().getTime());
			System.out.println("BarChart created at " + dateTime); 

		} catch (Exception i) {
			System.out.println(i);
		}
	} //end of main method

	//method #1 - JFreeChartScanner_Proj3b.getCurrency() 
	//reads the file and returns a upper-case string with newlines
	public static String getCurrency(Scanner s) throws FileNotFoundException{
		String cur = "";

		//reading the file in the current project folder
		File fileObj = new File("isoCodes.txt");
		s = new Scanner(fileObj);

		while(s.hasNextLine()){
			cur += "" + s.nextLine() + "\n"; //append to 'cur' with newline
		}		
		s.close();

		return cur.toUpperCase();
	}

	//method #2 - JFreeChartScanner_Proj3b.getURLString()
	//input the source and target currency to get a build a dynamic URL String
	public static String getURLString(String sourceCurrency, String targetCurrency){

		//creating a dynamic URL 
		String prefix = "http://download.finance.yahoo.com/d/quotes.csv?s=";
		String suffix = "=X&f=sl1d1t1ba&e=.csv";

		//the complete URL output - with source & target currency in upper-case
		String completeURL = String.format("%s%s%s%s", prefix, sourceCurrency.toUpperCase(),
				targetCurrency.toUpperCase(), suffix); 	
		return completeURL;
	}

	//method #3 - JFreeChartScanner_Proj3b.getExchangeRate()
	//input the getURLString() method to get the exchange rate value from web
	public static double getExchangeRate(String urlString) throws MalformedURLException, IOException{

		double rate = 0.0;
		try{
			//reading the URL page through Scanner
			Scanner webRead = new Scanner(new URL(urlString).openStream());
			while(webRead.hasNext()){
				String data = webRead.nextLine();
				String[] splitData = data.split(",");

				//in CSV file 0-index is name, 1-index contains the exchange rate
				rate += Double.parseDouble(splitData[1]);
			}
			webRead.close();

		}catch(NumberFormatException e){
			System.out.println("Invalid Input in Parameter!");
			System.exit(0);
		}
		return rate;
	}
}
