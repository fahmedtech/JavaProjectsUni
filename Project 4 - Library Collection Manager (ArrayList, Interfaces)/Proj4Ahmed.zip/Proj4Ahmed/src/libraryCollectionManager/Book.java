package libraryCollectionManager;

/**
 * @author Faizan Ahmed
 * @version 2.0 - 2/20/2016
 * Source Code File: Book.java

 * <p> IT313 <strong> Project 4 - Library Collection Manager </strong> </p>
 * <p> Description: Manages and creates a Book item, extends on Base class LibraryItem
  					and implements Serializable for Save() and Load() Methods for 
  					LibraryCollection class. </p>
*/

import java.io.Serializable;

public class Book extends LibraryItem implements Serializable {

	//private fields author, publisher, serialVersionUID;
	private String _author;
	private String _publisher;
	private static final long serialVersionUID = 2L;
	
	/**
	 * noarg constructor for Book class.
	 */
	public Book(){ }
	
	/**
	 * Constructor for objects of class Book
	 * @param id           The integer id of the LibraryItem.
	 * @param title		   The title of the LibraryItem.
	 * @param year		   The year LibraryItem was released.
	 * @param author	   The author of the Book.
	 * @param publisher	   The publisher of the Book.
	 */
	public Book(int id, String title, int year, 
				String author, String publisher){
		
		super(id, title, year);
		_author = author;
		_publisher = publisher;
	}

	//getters methods
	/**
	 * Get Author - return the Author name of the Book.
	 * @return The Book's author name.
	 */
	public String getAuthor() { return _author;	}
	
	/**
	 * Get Publisher - return the Publisher name of the Book.
	 * @return The Book's publisher name.
	 */
	public String getPublisher() { return _publisher; }
	
	/**
	 * Create a String to display the details of the Book.
	 * @return String for the Book item. 
	 */
	@Override
	public String toString(){
		return String.format("%s\nAuthor: %s\nPublisher: %s\n", 
							super.toString(), getAuthor(), getPublisher());
	}
	
}
