package libraryCollectionManager;

/**
 * @author Faizan Ahmed
 * @version 2.0 - 2/20/2016
 * Source Code File: LibraryCollection.java

 * <p> IT313 <strong> Project 4 - Library Collection Manager </strong> </p>
 * <p> Description: Manage the Book and MovieItem objects as Collection.
  					Implements Serializable for Save() and Load() Methods and 
  					Iterable to iterate over the LibraryCollection objects. </p>
 */

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Calendar;
import java.util.Collections;
import java.text.SimpleDateFormat;

public class LibraryCollection implements Iterable<LibraryItem>, Serializable {

	//private fields col, serialVersionUID
	private ArrayList<LibraryItem> _col;
	private static final long serialVersionUID = 4L;

	/**
	 * noarg constructor for LibraryCollection class.
	 */
	public LibraryCollection(){
		_col = new ArrayList<LibraryItem>();
	}

	/**
	 * Return the LibraryItem objects
	 * @return The Collection of LibraryItems
	 */
	@Override
	public Iterator<LibraryItem> iterator() {
		return _col.iterator();
	}

	/**
	 * Adds a new Book item to LibraryCollection
	 * @param b     Add a new book to the LibraryCollection
	 */
	public void addBook(Book b){
		_col.add(b);
	}

	/**
	 * Adds a new MovieItem to LibraryCollection
	 * @param m     Add a new movie to the LibraryCollection
	 */
	public void addMovieItem(MovieItem m){
		_col.add(m);
	}

	/**
	 * Get an Object from the LibraryItem with specified ID
	 * @param id     Input an Integer ID number to get the LibraryItem
	 * @return		 String output of the LibraryItem with the matching ID number.
	 * When running this method - log file is implemented with current date/time
	 */
	public String getItem(int id){
		String output = "";
		if(_col.size() == 0)
			System.out.println("Empty Library. \n");
		else{
			for(LibraryItem x: _col){
				if(x.getID() == id)
					output += x;
			}
		}		
		return output;
	}

	/**
	 * Remove an Object from the LibraryItem with specified ID
	 * @param id     Input an Integer ID number to remove the LibraryItem
	 * (Uses Clone method to handle java.util.concurrentmodificationexception Error),
	   when you remove the <strong> last object </strong> from the Collection
	 */
	public void removeItem(int id){
		@SuppressWarnings("unchecked")
		ArrayList<LibraryItem> clone = (ArrayList<LibraryItem>) _col.clone();
		for(LibraryItem x: clone){
			if(x.getID() == id)
				_col.remove(x);				
		}
	}

	/**
	 * Displays all of the LibraryItems from the LibraryCollection
	 * When running this method - log file is implemented with current date/time
	 */
	public void displayAll(){
		if(_col.size() == 0)
			System.out.println("Empty Library. \n");
		else{
			for(LibraryItem x: _col){
				System.out.println(x);
			}
		}
	}

	/**
	 * Reads the log file and Displays the information on the console with FileReader, BufferedReader
	 * @throws IOException     Constructs an IOException with null as its error detail message.
	 */
	public void displayLog() throws IOException{
		String filename = new SimpleDateFormat("MM.dd.yy").format(Calendar.getInstance().getTime()) + "_log.txt";
		FileReader reader = new FileReader(filename);
		BufferedReader bf = new BufferedReader(reader);

		String line;
		while((line = bf.readLine()) != null){
			System.out.println(line);
		}
		reader.close();
	}

	/**
	 * Creates a new Log file with current date using FileWriter Class
	 * @param log              String that contains log of method and time/date used.
	 * @throws IOException     Constructs an IOException with null as its error detail message.
	 */
	public void LogFile(String log) throws IOException{

		//creating a file with today's date
		String filename = new SimpleDateFormat("MM.dd.yy").format(Calendar.getInstance().getTime()) 
				+ "_log.txt";

		//writing the logs data of the methods to the file
		FileWriter writer = new FileWriter(filename);
		writer.write(log);
		writer.write("\r\n");
		writer.close();
	}

	/**
	 * Counts the Size of the LibraryItems in the LibraryCollection
	 * @return The LibraryCollection size
	 */
	public int countLibraryItems(){
		return _col.size();
	}

	/**
	 * Find the specified input substring LibraryItem title inside LibraryCollection
	 * @param substring     The title name substring to find.
	 * @return              The Sorted LibraryItem(s) that contains the substring
	 * When running this method - log file is implemented with current date/times
	 */
	public String find(String substring){
		String output = "";
		Collections.sort(_col);
		for(LibraryItem x : _col){
			if(x.getTitle().toLowerCase().contains(substring)){
				output += x + "\n";
			}
		}
		return output;
	}

	/**
	 * Serializes the LibraryCollection object to .ser file
	 * @throws IOException     Constructs an IOException with null as its error detail message.
	 */
	public void save() throws IOException{
		ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream("libraryCol.ser"));
		output.writeObject(_col);
		output.close();
	}

	/**
	 * De-serializes the LibraryCollection object to the console
	 * @throws IOException               Constructs an IOException with null as its error detail message.
	 * @throws ClassNotFoundException    Constructs a ClassNotFoundException with no detail message.
	 */
	@SuppressWarnings("unchecked")
	public void load() throws IOException, ClassNotFoundException{
		ObjectInputStream input = new ObjectInputStream(new FileInputStream("libraryCol.ser"));
		_col = (ArrayList<LibraryItem>) input.readObject();
		input.close();
	}
	


}