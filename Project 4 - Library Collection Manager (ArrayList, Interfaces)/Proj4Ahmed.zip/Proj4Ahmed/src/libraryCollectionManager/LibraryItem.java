package libraryCollectionManager;

/**
 * @author Faizan Ahmed
 * @version 2.0 - 2/20/2016
 * Source Code File: LibraryItem.java

 * <p> IT313 <strong> Project 4 - Library Collection Manager </strong> </p>
 * <p> Description: Manages and creates a LibraryItem, is the Base class for Book and 
 					MulimediaItem; and implements Serializable for Save() and Load() Methods for 
  					LibraryCollection class. Also Implements Comparable Interface to Sort LibraryItem ID(s).</p>
*/

import java.io.Serializable;

public class LibraryItem implements Serializable, Comparable<LibraryItem>{
	
	//private fields id, title, year, serialVersionUID;
	private int _id;
	private String _title;
	private int _year; 
	private static final long serialVersionUID = 1L;
	
	/**
	 * noarg constructor for LibraryItem class.
	 */
	public LibraryItem(){ }
		
	/**
	 * Constructor for objects of class Book
	 * @param id           The integer id of the LibraryItem.
	 * @param title		   The title of the LibraryItem.
	 * @param year		   The year LibraryItem was released.
	 */
	public LibraryItem(int id, String title, int year){
		_id = id;
		_title = title;
		_year = year;
	}

	//getters
	/**
	 * Get ID - return the Integer ID of the LibraryItem
	 * @return The LibraryItem's ID number.
	 */
	public int getID() { return _id; }
	
	/**
	 * Get Title - return the Title name of the LibraryItem
	 * @return The LibraryItem's title name.
	 */
	public String getTitle() { return _title; }
	
	/**
	 * Get Year - return the Year of the LibraryItem 
	 * @return The LibraryItem's release year.
	 */
	public int getYear() { return _year; }
	
	/**
	 * Create a String to display the details of the LibraryItem.
	 * @return String for the LibraryItem. 
	 */
	@Override
	public String toString(){
		return String.format("ID: %d\nTitle: %s\nYear:%d", getID(), getTitle(), getYear());
	}

	/**
	 * Comparable method to Sort the LibraryItem(s) in LibraryCollection find() method
	 * Sorts the ID numbers of the LibraryItem
	 */
	@Override
	public int compareTo(LibraryItem other){
		if(this._id > other._id)
			return 1;
		else if(this._id < other._id)
			return -1;
		else
			return 0;
	}
}
