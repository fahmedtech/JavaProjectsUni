package libraryCollectionManager;

/**
 * @author Faizan Ahmed
 * @version 2.0 - 2/20/2016
 * Source Code File: MainShell.java

 * <p> IT313 <strong> Project 4 - Library Collection Manager </strong> </p>
 * <p> Description: Shell program that runs the Project to
  				    Manage the Book and MovieItem objects as Collection. </p>
 */

import java.util.Scanner;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class MainShell {

	public static void main(String[] args) throws IOException, ClassNotFoundException{

		//initializing Book, MovieItem, LibraryCollection
		MovieItem item = new MovieItem();
		Book books = new Book();
		LibraryCollection col = new LibraryCollection();
		String logs = "";

		//Scanner object to read input
		Scanner in = new Scanner(System.in);
		boolean exit = false;  //if exit == true end the while loop - program terminates

		while(!exit){

			System.out.print("Enter a Command for the Library Collection Management System.\n" +
					"Add (B)ook, (D)isplay All, (F)ind, (G)et Item, (C)ount Library Items \n" + 
					"(L)oad, Add (M)ultimedia Item, (R)emove Item, (S)ave, L(O)gs, E(X)it: ");
			String input = in.nextLine(); //read input

			switch(input.toUpperCase()){
			case "B": //adding a Book item to LibraryCollection
				System.out.print("Integer ID #: ");
				String id = in.nextLine();
				int intID = Integer.parseInt(id);
				System.out.print("Title: ");
				String title = in.nextLine();
				System.out.print("Author: ");
				String author =  in.nextLine();
				System.out.print("Publisher: ");
				String publisher = in.nextLine();
				System.out.print("Year: ");
				String year =  in.nextLine();
				int intYear = Integer.parseInt(year);
				books = new Book(intID, title, intYear, author, publisher);
				col.addBook(books);

				System.out.println("\nThe Following Item has been added:");
				System.out.println(books);
				break;

			case "D": //display all LibraryItem(s) from LibraryCollection
				col.displayAll();
				
				//log format - appended to the 'logs' with newline at the end
				String ddateTime = new SimpleDateFormat("MM/dd/yy hh:mm:ss a").format(
						Calendar.getInstance().getTime());
				logs += "DisplayAll Method: " + ddateTime + "\r\n"; 
				col.LogFile(logs); //adding method (appends 'logs' info to file)
				break;

			case "F": //find the specified substring LibraryItem Title
				System.out.print("Enter LOWERCASE String for Title Search: ");
				String searchTitle = in.nextLine();
				System.out.println("Objects whose Title contains substring " + searchTitle + ": ");
				System.out.println(col.find(searchTitle));
				

				//log format - appended to the 'logs' with newline at the end
				String fdateTime = new SimpleDateFormat("MM/dd/yy hh:mm:ss a").format(
						Calendar.getInstance().getTime());
				logs += "Find Method: substring '" + searchTitle + "' " + fdateTime + "\r\n"; 
				col.LogFile(logs); //adding method (appends 'log' info to file)
				break;

			case "C": //counts the size of the LibraryCollection
				System.out.println(col.countLibraryItems() + "\n");
				break;

			case "G": //gets the specified Int ID LibraryItem
				System.out.print("Enter Integer ID# to get item: ");
				String gid = in.nextLine();
				int Intgid = Integer.parseInt(gid);	
				System.out.println("Item type: " + col.getClass());
				System.out.println(col.getItem(Intgid) + "\n");
				

				//log format - appended to the 'logs' with newline at the end
				String getdateTime = new SimpleDateFormat("MM/dd/yy hh:mm:ss a").format(
						Calendar.getInstance().getTime());
				logs += "Get Method: ID# '" + gid + "' " + getdateTime + "\r\n"; 
				
				col.LogFile(logs); //adding method (appends 'log' info to file)
				break;

			case "M": //adding a MovieItem to LibraryCollection
				System.out.print("Integer ID #: ");
				String mid = in.nextLine();
				int mintID = Integer.parseInt(mid);
				System.out.print("Title: ");
				String mtitle = in.nextLine();
				System.out.print("Actor: ");
				String actor =  in.nextLine();
				System.out.print("Director: ");
				String director = in.nextLine();
				System.out.print("Year: ");
				String myear =  in.nextLine();
				int mIntyear = Integer.parseInt(myear);
				System.out.print("Production: ");
				String prod =  in.nextLine();
				item = new MovieItem(mintID, mtitle, mIntyear, actor, director, prod);
				col.addMovieItem(item);

				System.out.println("\nThe Following Item has been added:");
				System.out.println("Item Type: " + item.getClass() + "\n" + 
						"ID: " + item.getID() + "\n" +
						"Title: " + item.getTitle() + "\n" +
						"Actor: " + item.getActor() + "\n" +
						"Director: " + item.getDirector() + "\n" +
						"Production: " + item.getProduction() + "\n" +
						"Year: " + item.getYear() + "\n");
				break;

			case "R": //removing a LibraryItem from LibraryCollection - specified ID
				System.out.print("Provide Integer ID# to Remove: ");
				String gid2 = in.nextLine();
				int Intgid2 = Integer.parseInt(gid2);	
				col.removeItem(Intgid2);
				System.out.println("Object with Integer ID# " + Intgid2 + " removed.\n");
				break;

			case "L": //de-serialize the .ser file to console
				System.out.println("Library Items Loaded! \n");
				col.load();
				break;

			case "S": //serialize the LibraryCollection to .ser file
				System.out.println("Library Items Saved! \n");
				col.save();
				break;				

			case "O": //read the log file and display data
				System.out.println("Log file data of Methods:");
				col.displayLog();
				break;

			case "X": //exit the program - change exit to true
				System.out.println("Thank you, Shell Terminated!");
				exit = true;
				break;

			default: //if input data is invalid
				System.out.println("Invalid Input! \n");

			}			
		}//end of while loop
		in.close();

	}

}
