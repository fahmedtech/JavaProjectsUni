package libraryCollectionManager;

/**
 * @author Faizan Ahmed
 * @version 2.0 - 2/20/2016
 * Source Code File: MovieItem.java

 * <p> IT313 <strong> Project 4 - Library Collection Manager </strong> </p>
 * <p> Description: Manages and creates a MultimediaItem, extends on Base class LibraryItem
  					and implements Serializable for Save() and Load() Methods for 
  					LibraryCollection class. </p>
*/

import java.io.Serializable;

public class MovieItem extends LibraryItem implements Serializable{

	//private fields actor, director, production, serialVersionUID;
	private String _actor;
	private String _director;
	private String _production;
	private static final long serialVersionUID = 3L;
	
	/**
	 * noarg constructor for MovieItem class.
	 */
	public MovieItem(){ }
	
	/**
	 * Constructor for objects of class MultimediaItem
	 * @param id           The integer id of the LibraryItem.
	 * @param title		   The title of the LibraryItem.
	 * @param year		   The year LibraryItem was released.
	 * @param actor        The actor of the Movie.
	 * @param director	   The director of the Movie.
	 * @param production   The production company of the Movie
	 */
	public MovieItem(int id, String title, int year,
				String actor, String director, String production){
		
		super(id, title, year);
		_actor = actor;
		_director = director;
		_production = production;
	}

	//getters
	/**
	 * Get Actor - return the Actor name of the MovieItem
	 * @return The MovieItem's actor name.
	 */
	public String getActor() { return _actor; }
	
	/**
	 * Get Director - return the Director name of the MovieItem
	 * @return The MovieItem's director name.
	 */
	public String getDirector() { return _director; }
	
	/**
	 * Get Production - return the Production company name of the MovieItem
	 * @return The MovieItem's production company name.
	 */
	public String getProduction() { return _production; }
	
	/**
	 * Create a String to display the details of the MovieItem.
	 * @return String for the MovieItem. 
	 */
	@Override
	public String toString(){
		return String.format("%s\nActor: %s\nDirector: %s\nProduction: %s\n", 
							 super.toString(), 
							 getActor(), getDirector(), getProduction());
	}
	
}