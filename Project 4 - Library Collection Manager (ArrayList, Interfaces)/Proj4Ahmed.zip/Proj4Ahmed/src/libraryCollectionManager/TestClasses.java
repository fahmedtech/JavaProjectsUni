package libraryCollectionManager;

/**
 * @author Faizan Ahmed
 * @version 2.0 - 2/20/2016
 * Source Code File: TestClasses.java

 * <p> IT313 <strong> Project 4 - Library Collection Manager </strong> </p>
 * <p> Description: Testing the classes to make sure they function. </p>
 */

public class TestClasses {

	public static void main(String[] args) {
				
		//testing LibraryItems class
		LibraryItem item1 = new LibraryItem(1, "UI UX", 2014);
		System.out.println(item1);
		System.out.println(item1.getID() + ", " + item1.getTitle() + ", " + item1.getYear());

		//testing Book class
		Book book1 = new Book(2, "Dark Knight Returns", 1999, "Frank", "DC Comics");
		System.out.println(book1);
		System.out.println(book1.getID() + ", " + book1.getAuthor() + ", " + book1.getPublisher());

		//testing MultimediaItem class
		MovieItem multi1 = new MovieItem(3, "King Kong", 2005, "Jack Black", "Peter J", "Universal Pics");
		System.out.println(multi1);
		System.out.println(multi1.getID() + ", " + 
				   multi1.getActor() + ", " + multi1.getDirector() + ", " + multi1.getProduction());
		 
		//testing LibraryCollection class
		LibraryCollection col1 = new LibraryCollection();

		col1.addBook(book1);
		//col1.addMovieItem(new MovieItem(3, "King Kong", 2005, "Jack Black", "Peter J", "Universal Pic"));
		col1.addMovieItem(multi1);
		
		for(LibraryItem x: col1){
			System.out.println(x);
		}

		System.out.println("ALL Items");
		col1.displayAll();

		System.out.println("Got " + col1.getItem(3));

		col1.removeItem(2);
		System.out.println("ALL Items");
		col1.displayAll();

		//System.out.println(col1.find("ko"));
	}

}
