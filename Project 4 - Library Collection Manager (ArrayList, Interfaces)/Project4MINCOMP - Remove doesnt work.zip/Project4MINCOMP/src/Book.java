import java.io.Serializable;

public class Book extends LibraryItem implements Serializable {

	public String _author, _publisher;
	private static final long serialVersionUID = 2L;

	public Book( ){ 
		
	}

	public Book(int id, String title, int year, String author, String publisher){
		super(id, title, year);
		_author = author;
		_publisher = publisher;
	}

	//get methods
	public String getAuthor( ) { 
		return _author;	
	}

	public String getPublisher( ) { 
		return _publisher; 
	}


	@Override
	public String toString( ){
		return super.toString( ) + "\n" + 
			   "Author: " + getAuthor( ) + "\n" + 
				"Publisher: " + getPublisher( ) + "\n";
	}

}
