import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;

public class LibraryCollection implements Iterable<LibraryItem>, Serializable {

	public ArrayList<LibraryItem> _col;
	private static final long serialVersionUID = 4L;

	public LibraryCollection( ){
		_col = new ArrayList<LibraryItem>( );
	}

	@Override
	public Iterator<LibraryItem> iterator( ) {
		return _col.iterator( );
	}

	public void addBook(Book bookItem){
		_col.add(bookItem);
	}

	public void addMusicCD(MusicCD musicCD){
		_col.add(musicCD);
	}

	public String getItem(int number){
		String res = "";
		for(LibraryItem item: _col){
			if(item.getID( ) == number)
				res += item;
		}
		return res;
	}

	//problem
	public void removeItem(int number){
		for(LibraryItem item : _col)
			if(item.getID() == number)
				_col.remove(item);	
			else
				System.out.println("");
	}

	public void displayAll( ){
		for(LibraryItem item: _col){
			System.out.println(item);
		}
	}


	public String find(String word){
		String res = "";
		for(LibraryItem item : _col){
			if(item.getTitle( ).trim( ).toLowerCase().contains(word)){
				res += item + "\n";
			}
		}
		return res;
	}

	public void save( ) throws IOException{
		ObjectOutputStream output = 
				new ObjectOutputStream(
				new FileOutputStream("colFile.ser"));
		output.writeObject(_col);
		output.close();
	}

	@SuppressWarnings("unchecked")
	public void load( ) throws IOException, ClassNotFoundException{
		ObjectInputStream input = 
				new ObjectInputStream(
				new FileInputStream("colFile.ser"));
		_col = (ArrayList<LibraryItem>) input.readObject( );
		input.close( );
	}

}