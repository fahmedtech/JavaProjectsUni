import java.io.Serializable;

public class LibraryItem implements Serializable{
	
	public String _title;
	public int _year, _id;
	private static final long serialVersionUID = 1L;
	

	public LibraryItem( ){ 
				
	}
		
	public LibraryItem(int id, String title, int year){
		_id = id;
		_title = title;
		_year = year;
	}

	//get methods
	public int getID( ) { 
		return _id; 
	}
	
	public String getTitle( ) { 
		return _title;
	}
	
	public int getYear( ) { 
		return _year; 
	}
	
	@Override
	public String toString( ){
		return "ID: " + getID( ) + "\n" +
			   "Title: " + getTitle( ) + "\n" + 
				"Year: " + getYear( );
	}

}
