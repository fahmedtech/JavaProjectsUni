import java.io.Serializable;

public class MusicCD extends LibraryItem implements Serializable{

	public String _performer, _composer, _label;
	private static final long serialVersionUID = 3L;

	public MusicCD( ) {

	}

	public MusicCD(int id, String title, int year, String performer, String composer, String label){
		super(id, title, year);
		_performer = performer;
		_composer = composer;
		_label = label;
	}

	//get methods
	public String getPerformer( ) { 
		return _performer; 
	}

	public String getComposer( ) { 
		return _composer; 
	}

	public String getLabel( ) { 
		return _label; 
	}


	@Override
	public String toString( ){
		return super.toString( ) + "\n" +
				"Performer: " + getPerformer( ) + "\n" +
				"Composer: " + getComposer( ) + "\n" + 
				"Label : " + getLabel( ) +  "\n";
	}

}


