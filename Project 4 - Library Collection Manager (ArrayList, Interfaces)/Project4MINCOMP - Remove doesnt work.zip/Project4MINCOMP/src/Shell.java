import java.io.IOException;
import java.util.Scanner;

public class Shell {
	public static void main(String[] args) throws IOException, ClassNotFoundException{

		Book book = new Book();
		MusicCD music = new MusicCD();
		LibraryCollection col = new LibraryCollection();

		Scanner scanner = new Scanner(System.in);
		boolean exitShell = false; 

		while(!exitShell){

			System.out.print("Enter a Command for the Library Collection Management System.\n" +
					"Add (B)ook, (D)isplay All, (F)ind, (G)et Item \n" + 
					"(L)oad, Add (M)usic CD, (R)emove Item, (S)ave: ");
			
			String data = scanner.nextLine(); 

			switch(data){
			case "B": 
				System.out.print("ID Number: ");
				String id = scanner.nextLine();
				int intID = Integer.parseInt(id);
				System.out.print("Title: ");
				String title = scanner.nextLine();
				System.out.print("Author: ");
				String author =  scanner.nextLine();
				System.out.print("Publisher: ");
				String publisher = scanner.nextLine();
				System.out.print("Year: ");
				String year =  scanner.nextLine();
				int intYear = Integer.parseInt(year);
				book = new Book(intID, title, intYear, author, publisher);
				col.addBook(book);

				System.out.println("");
				System.out.println("The Following Item has been added:");
				System.out.println(book);
				break;

			case "M": 
				System.out.print("ID Number: ");
				String musicid = scanner.nextLine();
				int ID = Integer.parseInt(musicid);
				System.out.print("Title: ");
				String musictitle = scanner.nextLine();
				System.out.print("Performer: ");
				String performer =  scanner.nextLine();
				System.out.print("Composer: ");
				String composer = scanner.nextLine();
				System.out.print("Year: ");
				String musicyear =  scanner.nextLine();
				int myear = Integer.parseInt(musicyear);
				System.out.print("Label: ");
				String label =  scanner.nextLine();
				music = new MusicCD(ID, musictitle, myear, performer, composer, label);
				col.addMusicCD(music);

				System.out.println("");
				System.out.println("The Following Item has been added:");
				System.out.println("Item Type: " + "Music" + "\n" + 
						"ID: " + music.getID() + "\n" +
						"Title: " + music.getTitle() + "\n" +
						"Performer: " + music.getPerformer() + "\n" +
						"Composer: " + music.getComposer() + "\n" +
						"Label: " + music.getLabel() + "\n" +
						"Year: " + music.getYear() + "\n");
				break;

			case "D": 
				col.displayAll();
				break;

			case "G": 
				System.out.print("Get ID item: ");
				String getID = scanner.nextLine();
				int IntgetID = Integer.parseInt(getID);	
				System.out.println(col.getItem(IntgetID) + "\n");
				break;
				
			case "F": 
				System.out.print("Enter title substring to search: ");
				String newtitle = scanner.nextLine();
				System.out.println("Objects title with substring " + newtitle);
				System.out.println(col.find(newtitle));
				break;

			case "R": 
				System.out.print("ID to Remove: ");
				String removeID = scanner.nextLine();
				int IntRemoveID = Integer.parseInt(removeID);	
				col.removeItem(IntRemoveID);
				System.out.println("Object ID " + IntRemoveID + " Removed.\n");
				break;

			case "L": 
				System.out.println("Items Loaded. \n");
				col.load();
				break;

			case "S": 
				System.out.println("Items Saved. \n");
				col.save();
				break;				

			default: 
				System.out.println("Terminated! \n");
				exitShell = true;
			}			
		}scanner.close();
	}
}
