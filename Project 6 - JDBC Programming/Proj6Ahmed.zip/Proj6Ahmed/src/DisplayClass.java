/**
 * @author Faizan Ahmed
 * IT313 - Project 6 - JDBC Programming
 * DisplayClass - Input a primary key, then display onscreen the corresponding data in a row of table.
 * Remember: You have to download the SQLite3 DB driver sqlite-jdbc-3.8.7.jar
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.Scanner;

public class DisplayClass {

	public static void main(String[] args) {
		
		Connection con = null;  //session with a specific db
		Statement st = null; //object for executing sql statements
		ResultSet rSt = null;  //table of data result of sql select statement
		
		int id = 0 , firstAppearance = 0;
		String sql, superHero, realName, gender, publisher = null;
		
		Scanner input = new Scanner(System.in);
		
		try{
			//defining Connection and Statement objects
			Class.forName("org.sqlite.JDBC");
			con = DriverManager.getConnection("jdbc:sqlite:superheroes.db");
			st = con.createStatement();
			
			while(id != -1){
				
				//read id and display corresponding table row
				System.out.print("Enter the Integer ID: ");
				id = input.nextInt();
				
				//sql statement - selecting from superheroes table
				sql = "select super_hero, real_name, gender, publisher, first_appearance from superheroes " +
					  "where id = " + id + ";";
				System.out.println(sql);
				
				//getting the values
				rSt = st.executeQuery(sql);
				while(rSt.next()){
					superHero = rSt.getString("super_hero");
					realName = rSt.getString("real_name");
					gender = rSt.getString("gender");
					publisher = rSt.getString("publisher");
					firstAppearance = rSt.getInt("first_appearance");
					
					String result = String.format("Super Hero: %s \n" + "Real Name: %s \n" +
								  		 "Gender: %s \n" +  "Publisher: %s \n" + "1st Appearance: %d \n" 
								  		 , superHero, realName, gender, publisher, firstAppearance);
					
					System.out.println(result);
				}
			}
		}//catching exceptions
		catch(SQLException e){
			System.out.println("SQLException.");
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
		}
		catch(ClassNotFoundException e){
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
		}
		finally{
			input.close(); //closing the file
		}
	}
}
