/**
 * @author Faizan Ahmed
 * IT313 - Project 6 - JDBC Programming
 * LoadClass - Loads the data from the .csv file into the database table.
 * Remember: You have to download the SQLite3 DB driver sqlite-jdbc-3.8.7.jar
 */

import java.io.File;
import java.io.FileNotFoundException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.Scanner;

public class LoadClass {

	public static void main(String[] args) {
		Connection con = null; //session with a specific db
		Statement st = null;  //object for executing sql statements
		Scanner ReadFile = null; //object for reading a file
		
		String sql1, sql2 = null; //for sql statements
		
		String line, superHero, realName, gender, publisher = null;
		int firstAppearance = 0;
		
		String[] field; //for splitting values
		
		try{
			//defining connection and statement objects and creating db file
			Class.forName("org.sqlite.JDBC");
			con = DriverManager.getConnection("jdbc:sqlite:superheroes.db");
			st = con.createStatement();
			
			//instantiate scanner to read file
			ReadFile = new Scanner(new File("heroes.txt"));
			
			//sql statement - create the table called superheroes
			sql1 = "create table if not exists " +
					"superheroes(id integer, " +
					"super_hero varchar(20), " +
					"real_name varchar(20), " +
					"gender varchar(1), " + 
					"publisher varchar(20), " +
					"first_appearance integer);";
			System.out.println("sql1: " + sql1);
			st.executeUpdate(sql1);
			
			//read and throw away the header line
			ReadFile.nextLine();
			
			//populate the table - with id as the primary key
			for(int id=1001; ReadFile.hasNextLine(); id++){
				line = ReadFile.nextLine();
				field = line.split(",");
				
				//all the fields in the txt file
				superHero = field[0].trim();
				realName = field[1].trim();
				gender = field[2].trim();
				publisher = field[3].trim();
				firstAppearance = Integer.parseInt(field[4].trim());
				
				//sql statement - to insert into table
				sql2 = String.format(
						"insert into superheroes (id, super_hero, real_name, gender, publisher, first_appearance) " +
						"values (%d, '%s', '%s', '%s', '%s', %d);",
						id, superHero, realName, gender, publisher, firstAppearance);
				System.out.println(sql2);
				
				st.executeUpdate(sql2);
			}
			con.close();
			
		}
		//catching exceptions
		catch (FileNotFoundException e){
			System.out.println("File queries.sql not found.");
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
		}
		catch (SQLException e){
			System.out.println("SQLException.");
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
		}
		catch (ClassNotFoundException e){
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
		}
		finally {
			ReadFile.close(); //closing the file
		}
	}
}
